
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <time.h>
#include <errno.h>

#define SIZE 10

struct shared_data
{
    int temp[SIZE];
    sem_t semaphore;
};

int main()
{
    int shmid;
    pid_t pid;


    shmid = shmget(IPC_PRIVATE, sizeof(struct shared_data),
                   IPC_CREAT | 0666);

    if(shmid == -1)
    {
        perror("shmget failed");
        return 1;
    }


    struct shared_data *data =
        (struct shared_data *)shmat(shmid, NULL, 0);

    if(data == (void *)-1)
    {
        perror("shmat failed");
        shmctl(shmid, IPC_RMID, NULL);
        return 1;
    }

    if(sem_init(&data->semaphore, 1, 0) == -1)
    {
        perror("sem_init failed");
        shmdt(data);
        shmctl(shmid, IPC_RMID, NULL);
        return 1;
    }

    pid = fork();

    if(pid < 0)
    {
        perror("fork failed");
        sem_destroy(&data->semaphore);
        shmdt(data);
        shmctl(shmid, IPC_RMID, NULL);
        return 1;
    }

    if(pid > 0)
    {
        srand(time(NULL));

        printf("\nPARENT PROCESS\n");
        printf("Generating temperature readings...\n");

        for(int i = 0; i < SIZE; i++)
        {
            data->temp[i] = rand() % 41 + 10;

            printf("%d ", data->temp[i]);
        }

        printf("\nData written successfully!\n");

        sem_post(&data->semaphore);

        wait(NULL);


        sem_destroy(&data->semaphore);
        shmdt(data);
        shmctl(shmid, IPC_RMID, NULL);

        printf("\nParent: Resources cleaned up.\n");
    }


    else
    {
        sem_wait(&data->semaphore);

        printf("\nCHILD PROCESS\n");
        printf("Reading temperatures from shared memory...\n");

        int max = data->temp[0];
        int min = data->temp[0];
        int sum = 0;

        for(int i = 0; i < SIZE; i++)
        {
            if(data->temp[i] > max)
                max = data->temp[i];

            if(data->temp[i] < min)
                min = data->temp[i];

            sum += data->temp[i];
        }

        float avg = (float)sum / SIZE;

        printf("\nMaximum Temperature = %d\n", max);
        printf("Minimum Temperature = %d\n", min);
        printf("Average Temperature = %.2f\n", avg);

        shmdt(data);
        exit(0);
    }

    return 0;
}
