
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <pthread.h>

#define SIZE 10
#define FIFO_NAME "start_fifo"

struct SharedBuffer
{
    int buffer[SIZE];
    int count;
    int read_index;
    int finished;

    pthread_mutex_t mutex;
    pthread_cond_t cond;
};

void *reader(void *arg)
{
    struct SharedBuffer *data = (struct SharedBuffer *)arg;

    for(int i = 1; i <= SIZE; i++)
    {
        pthread_mutex_lock(&data->mutex);

        data->buffer[data->count] = i;
        data->count++;

        printf("Reader: Generated Log ID %d\n", i);

        pthread_cond_signal(&data->cond);

        pthread_mutex_unlock(&data->mutex);

        usleep(100000);
    }

    pthread_mutex_lock(&data->mutex);
    data->finished = 1;
    pthread_cond_broadcast(&data->cond);
    pthread_mutex_unlock(&data->mutex);

    return NULL;
}

void *processor(void *arg)
{
    struct SharedBuffer *data = (struct SharedBuffer *)arg;

    while(1)
    {
        pthread_mutex_lock(&data->mutex);

        while(data->read_index == data->count && !data->finished)
        {
            pthread_cond_wait(&data->cond, &data->mutex);
        }

        if(data->read_index == data->count && data->finished)
        {
            pthread_mutex_unlock(&data->mutex);
            break;
        }

        int id = data->buffer[data->read_index];
        data->read_index++;

        pthread_mutex_unlock(&data->mutex);

        printf("Log ID: %d processed\n", id);
    }

    return NULL;
}

int main()
{
    pid_t pid;
    int fd;

    if(mkfifo(FIFO_NAME, 0666) == -1)
    {
        perror("mkfifo");
        return 1;
    }

    pid = fork();

    if(pid < 0)
    {
        perror("fork");
        unlink(FIFO_NAME);
        return 1;
    }

    if(pid == 0)
    {
        char message[20] = {0};

        fd = open(FIFO_NAME, O_RDONLY);

        if(fd == -1)
        {
            perror("open FIFO");
            exit(1);
        }

        int n = read(fd, message, sizeof(message) - 1);
        close(fd);

        if(n <= 0 || strcmp(message, "START") != 0)
        {
            printf("Invalid start message!\n");
            exit(1);
        }

        printf("Child: Received START message\n");

        struct SharedBuffer data = {0};

        pthread_mutex_init(&data.mutex, NULL);
        pthread_cond_init(&data.cond, NULL);

        pthread_t read_thread, process_thread;

        pthread_create(&read_thread, NULL, reader, &data);

        pthread_create(&process_thread, NULL, processor, &data);

        pthread_join(read_thread, NULL);
        pthread_join(process_thread, NULL);

        pthread_mutex_destroy(&data.mutex);
        pthread_cond_destroy(&data.cond);

        printf("Child: Both threads completed.\n");

        exit(0);
    }
    else
    {
        fd = open(FIFO_NAME, O_WRONLY);

        if(fd == -1)
        {
            perror("open FIFO");
            waitpid(pid, NULL, 0);
            unlink(FIFO_NAME);
            return 1;
        }

        write(fd, "START", 5);
        close(fd);

        printf("Parent: START message sent.\n");

        waitpid(pid, NULL, 0);

        unlink(FIFO_NAME);

        printf("Parent: Child process completed.\n");
    }

    return 0;
}
