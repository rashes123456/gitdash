
#include <stdio.h>
#include <stdlib.h>

void input(int **arr, int rows, int cols)
{
    int i, j;

    printf("\nEnter matrix elements:\n");

    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            printf("Element [%d][%d]: ", i, j);

            if(scanf("%d", &arr[i][j]) != 1)
            {
                printf("Invalid input!\n");
                exit(1);
            }
        }
    }
}

void display(int **arr, int rows, int cols)
{
    int i, j;

    printf("\nThe 2D Array is:\n");

    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            printf("%d\t", arr[i][j]);
        }

        printf("\n");
    }
}

int main()
{
    int rows, cols, i;

    printf("Enter number of rows and columns: ");

    if(scanf("%d %d", &rows, &cols) != 2 || rows <= 0 || cols <= 0)
    {
        printf("Invalid rows or columns!\n");
        return 1;
    }

    int **arr = (int **)malloc(rows * sizeof(int *));

    if(arr == NULL)
    {
        printf("Memory allocation failed!\n");
        return 1;
    }

    for(i = 0; i < rows; i++)
    {
        arr[i] = (int *)malloc(cols * sizeof(int));

        if(arr[i] == NULL)
        {
            printf("Memory allocation failed!\n");

            for(int j = 0; j < i; j++)
            {
                free(arr[j]);
            }

            free(arr);
            return 1;
        }
    }

    input(arr, rows, cols);

    display(arr, rows, cols);

    for(i = 0; i < rows; i++)
    {
        free(arr[i]);
    }

    free(arr);

    return 0;
}
