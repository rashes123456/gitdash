
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student
{
    int roll;
    char name[50];
    int marks[5];
    int total;
    float percentage;
    char result[10];
};

void input(struct Student s[], int n)
{
    int i, j;

    for(i = 0; i < n; i++)
    {
        printf("\nEnter details of student %d\n", i + 1);

        printf("Enter Roll Number: ");
        scanf("%d", &s[i].roll);

        printf("Enter Name: ");
        scanf(" %[^\n]", s[i].name);

        s[i].total = 0;

        for(j = 0; j < 5; j++)
        {
            printf("Enter marks of subject %d: ", j + 1);
            scanf("%d", &s[i].marks[j]);

            s[i].total += s[i].marks[j];
        }
    }
}

void calculate(struct Student s[], int n)
{
    int i;

    for(i = 0; i < n; i++)
    {
        s[i].percentage = s[i].total / 5.0;

        if(s[i].percentage >= 35)
            strcpy(s[i].result, "PASS");
        else
            strcpy(s[i].result, "FAIL");
    }

    printf("\nResults calculated successfully!\n");
}

void saveFile(struct Student s[], int n)
{
    int i;
    FILE *fp;

    fp = fopen("result.txt", "w");

    if(fp == NULL)
    {
        printf("File opening failed!\n");
        return;
    }

    for(i = 0; i < n; i++)
    {
        fprintf(fp, "\nRoll Number: %d", s[i].roll);
        fprintf(fp, "\nName: %s", s[i].name);
        fprintf(fp, "\nTotal: %d", s[i].total);
        fprintf(fp, "\nPercentage: %.2f", s[i].percentage);
        fprintf(fp, "\nResult: %s\n", s[i].result);
    }

    fclose(fp);

    printf("\nResults saved successfully!\n");
}

void displayFile()
{
    FILE *fp;
    char ch;

    fp = fopen("result.txt", "r");

    if(fp == NULL)
    {
        printf("File opening failed!\n");
        return;
    }

    printf("\n----- STUDENT RESULTS -----\n");

    while((ch = fgetc(fp)) != EOF)
    {
        putchar(ch);
    }

    fclose(fp);
}

void topper(struct Student s[], int n)
{
    int i, max = 0;

    for(i = 1; i < n; i++)
    {
        if(s[i].total > s[max].total)
        {
            max = i;
        }
    }

    printf("\n----- TOPPER DETAILS -----\n");
    printf("Roll Number: %d\n", s[max].roll);
    printf("Name: %s\n", s[max].name);
    printf("Total: %d\n", s[max].total);
    printf("Percentage: %.2f\n", s[max].percentage);
    printf("Result: %s\n", s[max].result);
}

int main()
{
    struct Student *s;
    int n, choice;
    int entered = 0, calculated = 0;

    printf("Enter number of students: ");
    scanf("%d", &n);

    if(n <= 0)
    {
        printf("Invalid number of students!");
        return 0;
    }

    s = (struct Student *)malloc(n * sizeof(struct Student));

    if(s == NULL)
    {
        printf("Memory allocation failed!");
        return 0;
    }

    do
    {
        printf("\n\n----- EXAM RESULT MENU -----\n");
        printf("1. Enter Student Details\n");
        printf("2. Calculate Result\n");
        printf("3. Save Results to File\n");
        printf("4. Display File Contents\n");
        printf("5. Display Topper\n");
        printf("6. Exit\n");

        printf("\nEnter your choice: ");
        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                input(s, n);
                entered = 1;
                calculated = 0;
                break;

            case 2:
                if(entered == 0)
                    printf("Enter student details first!");
                else
                {
                    calculate(s, n);
                    calculated = 1;
                }
                break;

            case 3:
                if(calculated == 0)
                    printf("Calculate results first!");
                else
                    saveFile(s, n);
                break;

            case 4:
                displayFile();
                break;

            case 5:
                if(calculated == 0)
                    printf("Calculate results first!");
                else
                    topper(s, n);
                break;

            case 6:
                printf("Exiting program...");
                break;

            default:
                printf("Invalid choice!");
        }

    } while(choice != 6);

    free(s);

    return 0;
}